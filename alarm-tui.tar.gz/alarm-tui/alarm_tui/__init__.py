"""alarm-tui: a minimal, self-contained terminal alarm clock for Arch Linux."""

__version__ = "1.0.0"
